How to install (windows instructions):
install Python
run the "INSTALL PACKAGES WITH THIS" .bat script
run main.py
